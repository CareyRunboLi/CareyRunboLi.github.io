#pragma once

#include <array>
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <future>
#include <limits>
#include <thread>
#include <vector>

bool AsymptoticRegion2DAll(double, double);
bool AsymptoticRegion3DAll(double, double, double);
bool AsymptoticRegion4DAll(double, double, double, double);
bool AsymptoticRegion5DAll(double, double, double, double, double);
bool AsymptoticRegion6DAll(double, double, double, double, double, double);
double integrandC4DLoss(double, double, double, double);
double integrandC6DLoss1(double, double, double, double, double, double);
double integrandC6DLoss2(double, double, double, double, double, double);
double integrandC4DRRLoss(double, double, double, double);
double integrandC6DRRLoss2(double, double, double, double, double, double);
double integrandC6DRRLoss3(double, double, double, double, double, double);

using cert_real = long double;

inline bool cert_asymptotic_C4(const double t1, const double t2,
                               const double t3, const double t4) {
    return AsymptoticRegion2DAll(t1, t2) ||
           AsymptoticRegion3DAll(t1, t2, t3) ||
           AsymptoticRegion4DAll(t1, t2, t3, t4);
}

inline bool cert_asymptotic_C6DLoss1(const double t1, const double t2,
                                     const double t3, const double t4,
                                     const double t5, const double t6) {
    return AsymptoticRegion2DAll(t1, t2) ||
           AsymptoticRegion3DAll(t1, t2, t3) ||
           AsymptoticRegion4DAll(t1, t2, t3, t4) ||
           AsymptoticRegion5DAll(t1, t2, t3, t4, t5) ||
           AsymptoticRegion6DAll(t1, t2, t3, t4, t5, t6);
}

inline bool cert_asymptotic_C6DLoss2(const double t1, const double t2,
                                     const double t3, const double t4,
                                     const double t5, const double t6) {
    const double r = 1.0 - t1 - t2 - t3 - t4 - t5;
    return AsymptoticRegion2DAll(t1, t2) ||
           AsymptoticRegion3DAll(t1, t2, t3) ||
           AsymptoticRegion4DAll(t1, t2, t3, t4) ||
           AsymptoticRegion5DAll(t1, t2, t3, t4, t5) ||
           AsymptoticRegion6DAll(r, t2, t3, t4, t5, t6);
}

inline bool cert_asymptotic_C4DRR(const double t1, const double t2,
                                  const double t3, const double t4) {
    const double r = 1.0 - t1 - t2 - t3;
    return AsymptoticRegion2DAll(t1, t2) ||
           AsymptoticRegion3DAll(t1, t2, t3) ||
           AsymptoticRegion4DAll(r, t2, t3, t4);
}

inline bool cert_asymptotic_C6DRR2(const double t1, const double t2,
                                   const double t3, const double t4,
                                   const double t5, const double t6) {
    const double r = 1.0 - t1 - t2 - t3;
    return AsymptoticRegion2DAll(t1, t2) ||
           AsymptoticRegion3DAll(t1, t2, t3) ||
           AsymptoticRegion4DAll(r, t2, t3, t4) ||
           AsymptoticRegion5DAll(r, t2, t3, t4, t5) ||
           AsymptoticRegion6DAll(r, t2, t3, t4, t5, t6);
}

inline bool cert_asymptotic_C6DRR3(const double t1, const double t2,
                                   const double t3, const double t4,
                                   const double t5, const double t6) {
    const double r = 1.0 - t1 - t2 - t3;
    const double q = t1 - t4;
    return AsymptoticRegion2DAll(t1, t2) ||
           AsymptoticRegion3DAll(t1, t2, t3) ||
           AsymptoticRegion4DAll(r, t2, t3, t4) ||
           AsymptoticRegion5DAll(q, t2, t3, t4, t5) ||
           AsymptoticRegion6DAll(q, t2, t3, t4, t5, t6);
}

inline cert_real cert_down(const cert_real x) {
    return std::nextafterl(x, -std::numeric_limits<cert_real>::infinity());
}

inline cert_real cert_up(const cert_real x) {
    return std::nextafterl(x, std::numeric_limits<cert_real>::infinity());
}

template <std::size_t D>
struct CertifiedBox {
    std::array<cert_real, D> lo{};
    std::array<cert_real, D> hi{};
};

struct CertifiedInterval {
    cert_real lo;
    cert_real hi;
};

inline CertifiedInterval cert_var(const cert_real x) {
    return {cert_down(x), cert_up(x)};
}

inline CertifiedInterval cert_add(const CertifiedInterval a,
                                  const CertifiedInterval b) {
    return {cert_down(a.lo + b.lo), cert_up(a.hi + b.hi)};
}

inline CertifiedInterval cert_sub(const CertifiedInterval a,
                                  const CertifiedInterval b) {
    return {cert_down(a.lo - b.hi), cert_up(a.hi - b.lo)};
}

inline CertifiedInterval cert_scale(const cert_real c,
                                    const CertifiedInterval x) {
    if (c >= 0) return {cert_down(c * x.lo), cert_up(c * x.hi)};
    return {cert_down(c * x.hi), cert_up(c * x.lo)};
}

inline CertifiedInterval cert_mul(const CertifiedInterval a,
                                  const CertifiedInterval b) {
    const cert_real p1 = a.lo * b.lo;
    const cert_real p2 = a.lo * b.hi;
    const cert_real p3 = a.hi * b.lo;
    const cert_real p4 = a.hi * b.hi;
    return {cert_down(std::min(std::min(p1, p2), std::min(p3, p4))),
            cert_up(std::max(std::max(p1, p2), std::max(p3, p4)))};
}

inline CertifiedInterval cert_div(const CertifiedInterval a,
                                  const CertifiedInterval b) {
    const cert_real q1 = a.lo / b.lo;
    const cert_real q2 = a.lo / b.hi;
    const cert_real q3 = a.hi / b.lo;
    const cert_real q4 = a.hi / b.hi;
    return {cert_down(std::min(std::min(q1, q2), std::min(q3, q4))),
            cert_up(std::max(std::max(q1, q2), std::max(q3, q4)))};
}

template <std::size_t D>
inline CertifiedInterval cert_coordinate(const CertifiedBox<D>& b,
                                         const std::size_t i) {
    return {b.lo[i], b.hi[i]};
}

template <std::size_t D>
inline CertifiedInterval cert_one_minus_prefix(const CertifiedBox<D>& b,
                                               const std::size_t n) {
    CertifiedInterval s{0, 0};
    for (std::size_t i = 0; i < n; ++i)
        s = cert_add(s, cert_coordinate(b, i));
    return cert_sub(cert_var(1), s);
}

inline bool cert_possible_ge(const CertifiedInterval a,
                             const CertifiedInterval b) {
    return a.hi >= b.lo;
}

inline bool cert_possible_lt(const CertifiedInterval a,
                             const CertifiedInterval b) {
    return a.lo <= b.hi;
}

template <std::size_t D>
inline cert_real cert_volume(const CertifiedBox<D>& b) {
    cert_real v = 1;
    for (std::size_t i = 0; i < D; ++i) {
        const cert_real width = cert_up(b.hi[i] - b.lo[i]);
        v = cert_up(v * std::max<cert_real>(0, width));
    }
    return cert_up(v);
}

inline cert_real cert_omega1_sup(const CertifiedInterval u) {
    if (u.hi < 1) return 0;
    if (u.lo >= 1 && u.hi < 2)
        return cert_up(1 / std::max<cert_real>(1, u.lo));
    if (u.lo >= 2 && u.hi < 3) return 0.57L;
    if (u.lo >= 3 && u.hi < 4) return 0.5644L;
    if (u.lo >= 4) return 0.5617L;
    return 1;
}

template <std::size_t D>
inline bool cert_leading_condition(const CertifiedBox<D>& b) {
    const auto t1 = cert_coordinate(b, 0);
    const auto t2 = cert_coordinate(b, 1);
    const auto one_minus_t1 = cert_one_minus_prefix(b, 1);
    const bool branch1 = cert_possible_lt(t1, cert_var(0.4L)) &&
                         cert_possible_lt(t2, t1) &&
                         cert_possible_lt(t2, cert_scale(1.0L / 3, one_minus_t1));
    const bool branch2 = cert_possible_ge(t1, cert_var(0.4L)) &&
                         cert_possible_lt(t2, cert_scale(0.5L, t1));
    return branch1 || branch2;
}

template <std::size_t D>
inline bool cert_ordered_region(const CertifiedBox<D>& b,
                               const std::size_t last,
                               const cert_real theta = 0.04L) {
    if (last >= D) return false;
    const auto t0 = cert_coordinate(b, 0);
    if (!cert_possible_ge(t0, cert_var(theta)) ||
        !cert_possible_lt(t0, cert_var(0.5L))) return false;

    for (std::size_t i = 1; i <= last; ++i) {
        const auto ti = cert_coordinate(b, i);
        const auto prev = cert_coordinate(b, i - 1);
        const auto remaining = cert_one_minus_prefix(b, i);
        if (!cert_possible_ge(ti, cert_var(theta)) ||
            !cert_possible_lt(ti, prev) ||
            !cert_possible_lt(ti, cert_scale(0.5L, remaining))) return false;
    }
    return true;
}

template <std::size_t D>
inline bool cert_ordered_region_c6_loss2(const CertifiedBox<D>& b) {
    if (!cert_ordered_region(b, 4)) return false;
    const auto t1 = cert_coordinate(b, 0);
    const auto t6 = cert_coordinate(b, 5);
    return cert_possible_ge(t6, cert_var(0.04L)) &&
           cert_possible_lt(t6, cert_scale(0.5L, t1));
}

template <std::size_t D>
inline bool cert_rr2_region(const CertifiedBox<D>& b) {
    if (!cert_ordered_region(b, 2)) return false;
    const auto t1 = cert_coordinate(b, 0);
    const auto t4 = cert_coordinate(b, 3);
    const auto t5 = cert_coordinate(b, 4);
    const auto t6 = cert_coordinate(b, 5);
    const auto rem12 = cert_one_minus_prefix(b, 2);
    return cert_possible_ge(t4, cert_var(0.04L)) &&
           cert_possible_lt(t4, cert_scale(0.5L, t1)) &&
           cert_possible_ge(t5, cert_var(0.04L)) &&
           cert_possible_lt(t5, cert_scale(0.5L, cert_sub(t1, t4))) &&
           cert_possible_ge(t6, cert_var(0.04L)) &&
           cert_possible_lt(t6, cert_scale(0.5L, cert_sub(cert_sub(t1, t4), t5))) &&
           cert_possible_lt(cert_coordinate(b, 2), cert_scale(0.5L, rem12));
}

template <std::size_t D>
inline bool cert_rr3_region(const CertifiedBox<D>& b) {
    if (!cert_ordered_region(b, 2)) return false;
    const auto t1 = cert_coordinate(b, 0);
    const auto t3 = cert_coordinate(b, 2);
    const auto t4 = cert_coordinate(b, 3);
    const auto t5 = cert_coordinate(b, 4);
    const auto t6 = cert_coordinate(b, 5);
    const auto rem123 = cert_one_minus_prefix(b, 3);
    return cert_possible_ge(t4, cert_var(0.04L)) &&
           cert_possible_lt(t4, cert_scale(0.5L, t1)) &&
           cert_possible_ge(t5, cert_var(0.04L)) &&
           cert_possible_lt(t5, cert_scale(0.5L, rem123)) &&
           cert_possible_ge(t6, cert_var(0.04L)) &&
           cert_possible_lt(t6, cert_scale(0.5L,
                                             cert_sub(rem123, t5)));
}

template <std::size_t D>
inline cert_real cert_product_denominator(const CertifiedBox<D>& b,
                                          const std::array<int, D>& powers) {
    cert_real denominator = 1;
    for (std::size_t i = 0; i < D; ++i)
        for (int p = 0; p < powers[i]; ++p)
            denominator = cert_down(denominator * b.lo[i]);
    return cert_down(denominator);
}

template <std::size_t D>
inline cert_real cert_c4_loss_majorant(const CertifiedBox<D>& b) {
    if (!cert_leading_condition(b) || !cert_ordered_region(b, 3)) return 0;
    const auto t4 = cert_coordinate(b, 3);
    const auto residual = cert_one_minus_prefix(b, 4);
    if (!cert_possible_ge(residual, t4)) return 0;
    const auto u = cert_div(residual, t4);
    return cert_up(cert_omega1_sup(u) /
                   cert_product_denominator(b, std::array<int, D>{1, 1, 1, 2}));
}

template <std::size_t D>
inline cert_real cert_c6_loss1_majorant(const CertifiedBox<D>& b) {
    if (!cert_leading_condition(b) || !cert_ordered_region(b, 5)) return 0;
    const auto t6 = cert_coordinate(b, 5);
    const auto residual = cert_one_minus_prefix(b, 6);
    if (!cert_possible_ge(residual, t6)) return 0;
    const auto u = cert_div(residual, t6);
    return cert_up(cert_omega1_sup(u) /
                   cert_product_denominator(b, std::array<int, D>{1, 1, 1, 1, 1, 2}));
}

template <std::size_t D>
inline cert_real cert_c6_loss2_majorant(const CertifiedBox<D>& b) {
    if (!cert_leading_condition(b) || !cert_ordered_region_c6_loss2(b)) return 0;
    const auto t1 = cert_coordinate(b, 0);
    const auto t5 = cert_coordinate(b, 4);
    const auto t6 = cert_coordinate(b, 5);
    const auto residual = cert_one_minus_prefix(b, 5);
    if (!cert_possible_ge(residual, t5) ||
        !cert_possible_ge(t1, cert_scale(2, t6))) return 0;
    const auto u1 = cert_div(residual, t5);
    const auto u2 = cert_div(cert_sub(t1, t6), t6);
    return cert_up(cert_omega1_sup(u1) * cert_omega1_sup(u2) /
                   cert_product_denominator(b, std::array<int, D>{0, 1, 1, 1, 2, 2}));
}

template <std::size_t D>
inline cert_real cert_c4_rr_loss_majorant(const CertifiedBox<D>& b) {
    if (!cert_leading_condition(b) || !cert_ordered_region(b, 2)) return 0;
    const auto t2 = cert_coordinate(b, 1);
    const auto t3 = cert_coordinate(b, 2);
    const auto t4 = cert_coordinate(b, 3);
    const auto residual = cert_one_minus_prefix(b, 3);
    if (!cert_possible_ge(residual, t3) ||
        !cert_possible_ge(cert_coordinate(b, 0), cert_scale(2, t4))) return 0;
    const auto u1 = cert_div(residual, t3);
    const auto u2 = cert_div(cert_sub(cert_coordinate(b, 0), t4), t4);
    const cert_real denominator = cert_product_denominator(
        b, std::array<int, D>{0, 1, 2, 2});
    return cert_up(cert_omega1_sup(u1) * cert_omega1_sup(u2) / denominator);
}

template <std::size_t D>
inline cert_real cert_c6_rr2_loss_majorant(const CertifiedBox<D>& b) {
    if (!cert_leading_condition(b) || !cert_rr2_region(b)) return 0;
    const auto t1 = cert_coordinate(b, 0);
    const auto t2 = cert_coordinate(b, 1);
    const auto t3 = cert_coordinate(b, 2);
    const auto t4 = cert_coordinate(b, 3);
    const auto t5 = cert_coordinate(b, 4);
    const auto t6 = cert_coordinate(b, 5);
    const auto residual1 = cert_sub(cert_var(1), cert_add(cert_add(t1, t2), t3));
    const auto residual2 = cert_sub(cert_sub(cert_sub(t1, t4), t5), t6);
    if (!cert_possible_ge(residual1, t3) ||
        !cert_possible_ge(cert_sub(cert_sub(t1, t4), t5),
                          cert_scale(2, t6))) return 0;
    const auto u1 = cert_div(residual1, t3);
    const auto u2 = cert_div(residual2, t6);
    return cert_up(cert_omega1_sup(u1) * cert_omega1_sup(u2) /
                   cert_product_denominator(b, std::array<int, D>{0, 1, 2, 1, 1, 2}));
}

template <std::size_t D>
inline cert_real cert_c6_rr3_loss_majorant(const CertifiedBox<D>& b) {
    if (!cert_leading_condition(b) || !cert_rr3_region(b)) return 0;
    const auto t1 = cert_coordinate(b, 0);
    const auto t2 = cert_coordinate(b, 1);
    const auto t3 = cert_coordinate(b, 2);
    const auto t4 = cert_coordinate(b, 3);
    const auto t5 = cert_coordinate(b, 4);
    const auto t6 = cert_coordinate(b, 5);
    const auto residual1 = cert_sub(cert_var(1),
                                    cert_add(cert_add(cert_add(t1, t2), t3),
                                             cert_add(t5, t6)));
    if (!cert_possible_ge(residual1, t6) ||
        !cert_possible_ge(t1, cert_scale(2, t4))) return 0;
    const auto u1 = cert_div(residual1, t6);
    const auto u2 = cert_div(cert_sub(t1, t4), t4);
    return cert_up(cert_omega1_sup(u1) * cert_omega1_sup(u2) /
                   cert_product_denominator(b, std::array<int, D>{0, 1, 1, 2, 1, 2}));
}

struct CertifiedUpperResult {
    cert_real upper = 0;
    cert_real estimate = 0;
    cert_real mesh_certificate = 0;
    std::size_t leaves = 0;
    std::size_t pruned_boxes = 0;
    int maximum_depth = 0;
};

struct CertifiedUpperOptions {
    int max_depth = 18;
    std::size_t requested_threads = 160;
    std::size_t max_leaves = 40000000;
};

template <std::size_t D, class Majorant>
inline void cert_refine_box(const CertifiedBox<D>& box,
                            const int depth,
                            const CertifiedUpperOptions& options,
                            Majorant majorant,
                            CertifiedUpperResult& out) {
    const cert_real m = majorant(box);
    if (!(m > 0)) {
        ++out.pruned_boxes;
        return;
    }
    if (depth >= options.max_depth || out.leaves >= options.max_leaves) {
        const cert_real diameter = [&]() {
            cert_real s = 0;
            for (std::size_t i = 0; i < D; ++i) {
                const cert_real w = box.hi[i] - box.lo[i];
                s += w * w;
            }
            return std::sqrt(s);
        }();
        out.upper = cert_up(out.upper + cert_up(cert_volume(box) * m));
        out.mesh_certificate = cert_up(out.mesh_certificate +
                                       cert_up(cert_volume(box) * m * diameter));
        ++out.leaves;
        out.maximum_depth = std::max(out.maximum_depth, depth);
        return;
    }

    std::size_t split = 0;
    cert_real score = -1;
    for (std::size_t i = 0; i < D; ++i) {
        const cert_real width = box.hi[i] - box.lo[i];
        const cert_real relative = width / std::max<cert_real>(box.lo[i], 1e-30L);
        if (relative > score) {
            score = relative;
            split = i;
        }
    }
    const cert_real mid = (box.lo[split] + box.hi[split]) * 0.5L;
    if (!(mid > box.lo[split] && mid < box.hi[split])) {
        out.upper = cert_up(out.upper + cert_up(cert_volume(box) * m));
        ++out.leaves;
        return;
    }

    CertifiedBox<D> left = box;
    CertifiedBox<D> right = box;
    left.hi[split] = cert_up(mid);
    right.lo[split] = cert_down(mid);
    cert_refine_box(left, depth + 1, options, majorant, out);
    cert_refine_box(right, depth + 1, options, majorant, out);
}

template <std::size_t D, class Majorant, class Evaluator>
inline void cert_refine_box_masked(const CertifiedBox<D>& box,
                                   const int depth,
                                   const CertifiedUpperOptions& options,
                                   Majorant majorant,
                                   Evaluator evaluator,
                                   CertifiedUpperResult& out) {
    const cert_real m = majorant(box);
    if (!(m > 0)) {
        ++out.pruned_boxes;
        return;
    }

    const bool terminal = depth >= options.max_depth ||
                          out.leaves >= options.max_leaves;
    if (terminal) {
        std::array<cert_real, D> center{};
        for (std::size_t i = 0; i < D; ++i)
            center[i] = (box.lo[i] + box.hi[i]) * 0.5L;

        const cert_real value = evaluator(center);
        if (std::isfinite(static_cast<double>(value)) && value > 0)
            out.estimate = cert_up(out.estimate +
                                   cert_up(cert_volume(box) * value));

        const cert_real diameter = [&]() {
            cert_real s = 0;
            for (std::size_t i = 0; i < D; ++i) {
                const cert_real w = box.hi[i] - box.lo[i];
                s += w * w;
            }
            return std::sqrt(s);
        }();

        out.upper = cert_up(out.upper + cert_up(cert_volume(box) * m));
        out.mesh_certificate = cert_up(
            out.mesh_certificate +
            cert_up(cert_volume(box) * m * diameter));
        ++out.leaves;
        out.maximum_depth = std::max(out.maximum_depth, depth);
        return;
    }

    std::size_t split = 0;
    cert_real score = -1;
    for (std::size_t i = 0; i < D; ++i) {
        const cert_real width = box.hi[i] - box.lo[i];
        const cert_real relative =
            width / std::max<cert_real>(box.lo[i], 1e-30L);
        if (relative > score) {
            score = relative;
            split = i;
        }
    }

    const cert_real mid = (box.lo[split] + box.hi[split]) * 0.5L;
    if (!(mid > box.lo[split] && mid < box.hi[split])) {
        std::array<cert_real, D> center{};
        for (std::size_t i = 0; i < D; ++i)
            center[i] = (box.lo[i] + box.hi[i]) * 0.5L;
        const cert_real value = evaluator(center);
        if (std::isfinite(static_cast<double>(value)) && value > 0)
            out.estimate = cert_up(out.estimate +
                                   cert_up(cert_volume(box) * value));
        out.upper = cert_up(out.upper + cert_up(cert_volume(box) * m));
        ++out.leaves;
        return;
    }

    CertifiedBox<D> left = box;
    CertifiedBox<D> right = box;
    left.hi[split] = cert_up(mid);
    right.lo[split] = cert_down(mid);

    cert_refine_box_masked(left, depth + 1, options,
                           majorant, evaluator, out);
    cert_refine_box_masked(right, depth + 1, options,
                           majorant, evaluator, out);
}

template <std::size_t D, class Majorant, class Evaluator>
inline CertifiedUpperResult certified_upper_nd_masked(
    const std::array<cert_real, D>& lower,
    const std::array<cert_real, D>& upper,
    Majorant majorant,
    Evaluator evaluator,
    const CertifiedUpperOptions& options = {}) {
    CertifiedBox<D> initial;
    initial.lo = lower;
    initial.hi = upper;

    const unsigned hw =
        std::max(1u, std::thread::hardware_concurrency());
    const std::size_t workers = std::max<std::size_t>(
        1, std::min({options.requested_threads,
                     static_cast<std::size_t>(hw),
                     static_cast<std::size_t>(32)}));
    const std::size_t slabs = std::min<std::size_t>(workers, 16);

    std::vector<std::future<CertifiedUpperResult>> jobs;
    jobs.reserve(slabs);

    for (std::size_t s = 0; s < slabs; ++s) {
        CertifiedBox<D> slab = initial;
        const cert_real width =
            cert_up(initial.hi[0] - initial.lo[0]);
        const cert_real left = cert_down(
            initial.lo[0] + width * static_cast<cert_real>(s) /
            static_cast<cert_real>(slabs));
        const cert_real right = cert_up(
            initial.lo[0] + width * static_cast<cert_real>(s + 1) /
            static_cast<cert_real>(slabs));

        slab.lo[0] = (s == 0) ? initial.lo[0] : cert_down(left);
        slab.hi[0] = (s + 1 == slabs) ? initial.hi[0] : cert_up(right);

        jobs.emplace_back(std::async(
            std::launch::async,
            [slab, majorant, evaluator, options]() mutable {
                CertifiedUpperResult r;
                cert_refine_box_masked(slab, 0, options,
                                       majorant, evaluator, r);
                return r;
            }));
    }

    CertifiedUpperResult result;
    for (auto& job : jobs) {
        const CertifiedUpperResult r = job.get();
        result.upper = cert_up(result.upper + r.upper);
        result.estimate = cert_up(result.estimate + r.estimate);
        result.mesh_certificate = cert_up(
            result.mesh_certificate + r.mesh_certificate);
        result.leaves += r.leaves;
        result.pruned_boxes += r.pruned_boxes;
        result.maximum_depth =
            std::max(result.maximum_depth, r.maximum_depth);
    }
    return result;
}

template <std::size_t D, class Majorant>
inline CertifiedUpperResult certified_upper_nd(
    const std::array<cert_real, D>& lower,
    const std::array<cert_real, D>& upper,
    Majorant majorant,
    const CertifiedUpperOptions& options = {}) {
    CertifiedBox<D> initial;
    initial.lo = lower;
    initial.hi = upper;

    const unsigned hw = std::max(1u, std::thread::hardware_concurrency());
    const std::size_t workers = std::max<std::size_t>(
        1, std::min({options.requested_threads, static_cast<std::size_t>(hw),
                     static_cast<std::size_t>(32)}));
    const std::size_t slabs = std::min<std::size_t>(workers, 16);
    std::vector<std::future<CertifiedUpperResult>> jobs;
    jobs.reserve(slabs);

    for (std::size_t s = 0; s < slabs; ++s) {
        CertifiedBox<D> slab = initial;
        const cert_real width = cert_up(initial.hi[0] - initial.lo[0]);
        const cert_real left = cert_down(initial.lo[0] + width * static_cast<cert_real>(s) /
                                                       static_cast<cert_real>(slabs));
        const cert_real right = cert_up(initial.lo[0] + width * static_cast<cert_real>(s + 1) /
                                                      static_cast<cert_real>(slabs));
        slab.lo[0] = (s == 0) ? initial.lo[0] : cert_down(left);
        slab.hi[0] = (s + 1 == slabs) ? initial.hi[0] : cert_up(right);
        jobs.emplace_back(std::async(std::launch::async,
            [slab, majorant, options]() mutable {
                CertifiedUpperResult r;
                cert_refine_box(slab, 0, options, majorant, r);
                return r;
            }));
    }

    CertifiedUpperResult result;
    for (auto& job : jobs) {
        const CertifiedUpperResult r = job.get();
        result.upper = cert_up(result.upper + r.upper);
        result.mesh_certificate = cert_up(result.mesh_certificate + r.mesh_certificate);
        result.leaves += r.leaves;
        result.pruned_boxes += r.pruned_boxes;
        result.maximum_depth = std::max(result.maximum_depth, r.maximum_depth);
    }
    return result;
}

inline CertifiedUpperResult certified_upper_C4DLoss(
    const cert_real a1, const cert_real b1, const cert_real a2, const cert_real b2,
    const cert_real a3, const cert_real b3, const cert_real a4, const cert_real b4,
    const CertifiedUpperOptions& options = {}) {
    const auto evaluator = [](const std::array<cert_real, 4>& x) -> cert_real {
        const double t1 = static_cast<double>(x[0]);
        const double t2 = static_cast<double>(x[1]);
        const double t3 = static_cast<double>(x[2]);
        const double t4 = static_cast<double>(x[3]);
        if (cert_asymptotic_C4(t1, t2, t3, t4)) return 0;
        return static_cast<cert_real>(integrandC4DLoss(t1, t2, t3, t4));
    };
    return certified_upper_nd_masked<4>(
        {a1, a2, a3, a4}, {b1, b2, b3, b4},
        cert_c4_loss_majorant<4>, evaluator, options);
}

inline CertifiedUpperResult certified_upper_C6DLoss1(
    const cert_real a1, const cert_real b1, const cert_real a2, const cert_real b2,
    const cert_real a3, const cert_real b3, const cert_real a4, const cert_real b4,
    const cert_real a5, const cert_real b5, const cert_real a6, const cert_real b6,
    const CertifiedUpperOptions& options = {}) {
    const auto evaluator = [](const std::array<cert_real, 6>& x) -> cert_real {
        const double t1 = static_cast<double>(x[0]);
        const double t2 = static_cast<double>(x[1]);
        const double t3 = static_cast<double>(x[2]);
        const double t4 = static_cast<double>(x[3]);
        const double t5 = static_cast<double>(x[4]);
        const double t6 = static_cast<double>(x[5]);
        if (cert_asymptotic_C6DLoss1(t1, t2, t3, t4, t5, t6)) return 0;
        return static_cast<cert_real>(integrandC6DLoss1(
            t1, t2, t3, t4, t5, t6));
    };
    return certified_upper_nd_masked<6>(
        {a1, a2, a3, a4, a5, a6}, {b1, b2, b3, b4, b5, b6},
        cert_c6_loss1_majorant<6>, evaluator, options);
}

inline CertifiedUpperResult certified_upper_C6DLoss2(
    const cert_real a1, const cert_real b1, const cert_real a2, const cert_real b2,
    const cert_real a3, const cert_real b3, const cert_real a4, const cert_real b4,
    const cert_real a5, const cert_real b5, const cert_real a6, const cert_real b6,
    const CertifiedUpperOptions& options = {}) {
    const auto evaluator = [](const std::array<cert_real, 6>& x) -> cert_real {
        const double t1 = static_cast<double>(x[0]);
        const double t2 = static_cast<double>(x[1]);
        const double t3 = static_cast<double>(x[2]);
        const double t4 = static_cast<double>(x[3]);
        const double t5 = static_cast<double>(x[4]);
        const double t6 = static_cast<double>(x[5]);
        if (cert_asymptotic_C6DLoss2(t1, t2, t3, t4, t5, t6)) return 0;
        return static_cast<cert_real>(integrandC6DLoss2(
            t1, t2, t3, t4, t5, t6));
    };
    return certified_upper_nd_masked<6>(
        {a1, a2, a3, a4, a5, a6}, {b1, b2, b3, b4, b5, b6},
        cert_c6_loss2_majorant<6>, evaluator, options);
}

inline CertifiedUpperResult certified_upper_C4DRRLoss(
    const cert_real a1, const cert_real b1, const cert_real a2, const cert_real b2,
    const cert_real a3, const cert_real b3, const cert_real a4, const cert_real b4,
    const CertifiedUpperOptions& options = {}) {
    const auto evaluator = [](const std::array<cert_real, 4>& x) -> cert_real {
        const double t1 = static_cast<double>(x[0]);
        const double t2 = static_cast<double>(x[1]);
        const double t3 = static_cast<double>(x[2]);
        const double t4 = static_cast<double>(x[3]);
        if (cert_asymptotic_C4DRR(t1, t2, t3, t4)) return 0;
        return static_cast<cert_real>(integrandC4DRRLoss(t1, t2, t3, t4));
    };
    return certified_upper_nd_masked<4>(
        {a1, a2, a3, a4}, {b1, b2, b3, b4},
        cert_c4_rr_loss_majorant<4>, evaluator, options);
}

inline CertifiedUpperResult certified_upper_C6DRRLoss2(
    const cert_real a1, const cert_real b1, const cert_real a2, const cert_real b2,
    const cert_real a3, const cert_real b3, const cert_real a4, const cert_real b4,
    const cert_real a5, const cert_real b5, const cert_real a6, const cert_real b6,
    const CertifiedUpperOptions& options = {}) {
    const auto evaluator = [](const std::array<cert_real, 6>& x) -> cert_real {
        const double t1 = static_cast<double>(x[0]);
        const double t2 = static_cast<double>(x[1]);
        const double t3 = static_cast<double>(x[2]);
        const double t4 = static_cast<double>(x[3]);
        const double t5 = static_cast<double>(x[4]);
        const double t6 = static_cast<double>(x[5]);
        if (cert_asymptotic_C6DRR2(t1, t2, t3, t4, t5, t6)) return 0;
        return static_cast<cert_real>(integrandC6DRRLoss2(
            t1, t2, t3, t4, t5, t6));
    };
    return certified_upper_nd_masked<6>(
        {a1, a2, a3, a4, a5, a6}, {b1, b2, b3, b4, b5, b6},
        cert_c6_rr2_loss_majorant<6>, evaluator, options);
}

inline CertifiedUpperResult certified_upper_C6DRRLoss3(
    const cert_real a1, const cert_real b1, const cert_real a2, const cert_real b2,
    const cert_real a3, const cert_real b3, const cert_real a4, const cert_real b4,
    const cert_real a5, const cert_real b5, const cert_real a6, const cert_real b6,
    const CertifiedUpperOptions& options = {}) {
    const auto evaluator = [](const std::array<cert_real, 6>& x) -> cert_real {
        const double t1 = static_cast<double>(x[0]);
        const double t2 = static_cast<double>(x[1]);
        const double t3 = static_cast<double>(x[2]);
        const double t4 = static_cast<double>(x[3]);
        const double t5 = static_cast<double>(x[4]);
        const double t6 = static_cast<double>(x[5]);
        if (cert_asymptotic_C6DRR3(t1, t2, t3, t4, t5, t6)) return 0;
        return static_cast<cert_real>(integrandC6DRRLoss3(
            t1, t2, t3, t4, t5, t6));
    };
    return certified_upper_nd_masked<6>(
        {a1, a2, a3, a4, a5, a6}, {b1, b2, b3, b4, b5, b6},
        cert_c6_rr3_loss_majorant<6>, evaluator, options);
}
